import hashlib
import json
import time

from ..Config import DEBUG
from ..Logging import logger
from ..Socket import PRIORITY_BULK


class ConnectionSubscribers:
    """Maps a WebSocket connection to its event id for one listener."""

    def __init__(self):
        self._subs = {}

    def is_empty(self):
        return not self._subs

    def subscribe(self, connection, event_id):
        existing = self._subs.get(connection)
        if existing is not None:
            return existing
        self._subs[connection] = event_id
        return event_id

    def unsubscribe(self, connection):
        if connection not in self._subs:
            return False
        del self._subs[connection]
        return True

    def items(self):
        return list(self._subs.items())

    def send_each(self, socket, data):
        for conn, event_id in self.items():
            socket.send_to(conn, event_id, data)


# Listener props that Live fires many times per second and whose only
# useful value is the latest one. They are coalesced and sent at most
# THROTTLE_SECONDS apart, on the bulk lane, instead of one frame per change.
THROTTLED_SUFFIXES = ("meter_left", "meter_right", "meter_level", "playing_position")
THROTTLE_SECONDS = 0.033  # ~30 updates per second: smooth, and cheap for Live


class Interface:
    listeners = {}  # noqa: RUF012
    obj_ids = {}  # noqa: RUF012
    _dirty = {}  # noqa: RUF012  key -> True for throttled listeners with news
    _last_flush = 0.0

    @staticmethod
    def flush_throttled(socket):
        if not Interface._dirty:
            return
        now = time.time()
        if now - Interface._last_flush < THROTTLE_SECONDS:
            return
        Interface._last_flush = now
        dirty = list(Interface._dirty.keys())
        Interface._dirty.clear()
        for key in dirty:
            entry = Interface.listeners.get(key)
            if not entry:
                continue
            try:
                value = entry["iface"].get_prop(entry["ns"], entry["prop"])
            except Exception:
                continue
            if isinstance(value, float):
                value = round(value, 3)
            for conn, event_id in entry["subscribers"].items():
                socket.send_to(conn, event_id, value, priority=PRIORITY_BULK)

    @staticmethod
    def save_obj(obj):
        try:
            obj_id = f"live_{obj._live_ptr}"
        except:
            obj_id = f"id_{id(obj)}"

        Interface.obj_ids[obj_id] = obj
        return obj_id

    @staticmethod
    def get_obj(obj_id):
        obj = Interface.obj_ids.get(obj_id)
        if obj is None:
            raise Exception(f"Unknown object id: {obj_id}")
        return obj

    def __init__(self, c_instance, socket):
        self.ableton = c_instance
        self.socket = socket

    def log_debug(self, message):
        if DEBUG:
            logger.debug(message)

    def get_ns(self, nsid):
        return Interface.get_obj(nsid)

    def format_result(self, result, etag, cache):
        """Returns the payload the client expects for a command result."""
        if not cache:
            return result

        def jsonReplace(o):
            return str(o)

        response = json.dumps(result, default=jsonReplace, ensure_ascii=False)
        hash = hashlib.md5(response.encode("utf-8", "replace")).hexdigest()

        if hash == etag:
            return {"__cached": True}
        return {"data": result, "etag": hash}

    def dispatch(self, payload, connection):
        """Runs one command and returns its result value (or cache wrapper)."""
        name = payload.get("name")
        etag = payload.get("etag")
        args = payload.get("args", {})
        cache = payload.get("cache", False)
        nsid = payload.get("nsid")

        ns = self.get_ns(nsid)

        if hasattr(self, name) and callable(getattr(self, name)):
            if name == "add_listener" or name == "remove_listener":
                kwargs = dict(args)
                kwargs.pop("connection", None)
                result = getattr(self, name)(ns=ns, connection=connection, **kwargs)
            else:
                result = getattr(self, name)(ns=ns, **args)
            return self.format_result(result, etag, cache)

        if hasattr(ns, name) and callable(getattr(ns, name)):
            if isinstance(args, dict):
                result = getattr(ns, name)(**args)
            elif isinstance(args, list):
                result = getattr(ns, name)(*args)
            else:
                raise Exception(f"Function call failed: {args} are invalid arguments")
            return self.format_result(result, etag, cache)

        raise Exception(f"Function call failed: {name} doesn't exist or isn't callable")

    def add_listener(self, ns, prop, eventId, connection, nsid="Default"):
        try:
            add_fn = getattr(ns, f"add_{prop}_listener")
        except:
            raise Exception(f"Listener {prop} does not exist.")

        key = f"{nsid}:{prop}"
        self.log_debug(f"Listener key: {key}")

        if key in self.listeners:
            return self.listeners[key]["subscribers"].subscribe(connection, eventId)

        subscribers = ConnectionSubscribers()
        subscribers.subscribe(connection, eventId)

        throttled = prop.endswith(THROTTLED_SUFFIXES)

        def fn():
            if throttled:
                Interface._dirty[key] = True
                return
            value = self.get_prop(ns, prop)
            entry = self.listeners.get(key)
            if not entry:
                return
            entry["subscribers"].send_each(self.socket, value)

        self.log_debug(f"Attaching listener: {key}, event ID: {eventId}")

        try:
            add_fn(fn)
            self.listeners[key] = {
                "fn": fn,
                "subscribers": subscribers,
                "ns": ns,
                "prop": prop,
                "iface": self,
            }
        except Exception as e:
            raise Exception(f"Listener {prop} could not be attached: {e}")

        return eventId

    def remove_listener(self, ns, prop, connection, nsid="Default"):
        key = f"{nsid}:{prop}"
        self.log_debug(f"Remove key: {key}")
        if key not in self.listeners:
            raise Exception(f"Listener {prop} does not exist.")

        subscribers = self.listeners[key]["subscribers"]
        if not subscribers.unsubscribe(connection):
            raise Exception(f"Listener {prop} does not exist.")
        if not subscribers.is_empty():
            return True

        try:
            Interface._detach_listener(key)
            return True
        except Exception as e:
            raise Exception(f"Listener {prop} could not be removed: {e}")

    @staticmethod
    def drop_connection(connection):
        empty = []
        for key, entry in list(Interface.listeners.items()):
            subscribers = entry["subscribers"]
            subscribers.unsubscribe(connection)
            if subscribers.is_empty():
                empty.append(key)
        for key in empty:
            try:
                Interface._detach_listener(key)
            except Exception:
                logger.error(f"Could not detach listener {key}")
                Interface.listeners.pop(key, None)

    @staticmethod
    def _detach_listener(key):
        entry = Interface.listeners.get(key)
        if not entry:
            return
        ns = entry.get("ns")
        prop = entry.get("prop")
        fn = entry.get("fn")
        remove_fn = getattr(ns, f"remove_{prop}_listener")
        remove_fn(fn)
        Interface.listeners.pop(key, None)

    def get_prop(self, ns, prop):
        try:
            get_fn = getattr(self, f"get_{prop}")
        except:

            def get_fn(ns):
                result = getattr(ns, prop)
                return result

        return get_fn(ns)

    def set_prop(self, ns, prop, value):
        try:
            set_fn = getattr(self, f"set_{prop}")
        except:

            def set_fn(ns, value):
                return setattr(ns, prop, value)

        return set_fn(ns, value)

    def _is_listener_api(self, name):
        if name.endswith("_has_listener"):
            return True
        if name.endswith("_listener") and name.startswith(("add_", "remove_")):
            return True
        return False

    def get_observable_properties(self, ns):
        props = []
        for name in dir(ns):
            if name.startswith("add_") and name.endswith("_listener"):
                props.append(name[4:-9])  # strip add_ / _listener
        return sorted(set(props))

    def get_available_properties(self, ns):
        props = []
        for name in dir(ns):
            if name.startswith("_") or self._is_listener_api(name):
                continue
            try:
                attr = getattr(ns, name)
            except:
                continue
            if callable(attr):
                continue
            props.append(name)
        return sorted(props)

    def get_available_functions(self, ns):
        funcs = []
        for name in dir(ns):
            if name.startswith("_") or self._is_listener_api(name):
                continue
            try:
                attr = getattr(ns, name)
            except:
                continue
            if not callable(attr):
                continue
            # Skip nested Live types/enums (Song.View, Track.monitoring_states)
            if name[:1].isupper():
                continue
            try:
                if isinstance(attr, type) or (
                    getattr(attr, "__name__", None) and hasattr(attr, "__bases__")
                ):
                    continue
            except:
                pass
            funcs.append(name)
        return sorted(funcs)
