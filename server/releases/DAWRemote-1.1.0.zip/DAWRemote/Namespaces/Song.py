
import Live

from .CuePoint import CuePoint
from .Device import Device
from .Interface import Interface
from .Scene import Scene
from .Track import Track
from .TuningSystem import TuningSystem


class Song(Interface):
    def __init__(self, c_instance, socket):
        super().__init__(c_instance, socket)
        self.song = self.ableton.song()

    def get_ns(self, nsid):
        return self.song

    def create_audio_track(self, ns, index):
        return Track.serialize_track(ns.create_audio_track(index))

    def create_midi_track(self, ns, index):
        return Track.serialize_track(ns.create_midi_track(index))

    def create_return_track(self, ns):
        return Track.serialize_track(ns.create_return_track())

    def create_scene(self, ns, index):
        return Scene.serialize_scene(ns.create_scene(index))

    def get_clip_trigger_quantization(self, ns):
        return str(ns.clip_trigger_quantization)

    def get_cue_points(self, ns):
        sorted_points = sorted(ns.cue_points, key=lambda cue: cue.time)
        return map(CuePoint.serialize_cue_point, sorted_points)

    def get_appointed_device(self, ns):
        return Device.serialize_device(ns.appointed_device)

    def get_master_track(self, ns):
        return Track.serialize_track(ns.master_track)

    def get_midi_recording_quantization(self, ns):
        return str(ns.midi_recording_quantization)

    def get_return_tracks(self, ns):
        return map(Track.serialize_track, ns.return_tracks)

    def get_scenes(self, ns):
        return map(Scene.serialize_scene, ns.scenes)

    def get_tracks(self, ns):
        return map(Track.serialize_track, ns.tracks)

    def get_tuning_system(self, ns):
        return TuningSystem.serialize_tuning_system(ns.tuning_system)

    def get_visible_tracks(self, ns):
        return map(Track.serialize_track, ns.visible_tracks)

    def get_data(self, ns, key):
        return ns.get_data(key, None)

    def get_current_smpte_song_time(self, ns, timeFormat):
        time = ns.get_current_smpte_song_time(
            getattr(Live.Song.TimeFormat, str(timeFormat))
        )
        return {
            "hours": time.hours,
            "minutes": time.minutes,
            "seconds": time.seconds,
            "frames": time.frames,
        }

    def measure_seconds(self, ns, beats):
        """Wall-clock time (seconds from the song start) of each position in
        `beats`, as Live computes it — tempo automation and tempo changes
        included. Live has no direct beats->time call, so the transport is
        moved to each position, its time read, and then put back. Only while
        stopped, so nothing audible happens."""
        if ns.is_playing:
            raise Exception("Live está reproduciendo: detén el transporte para medir")
        original = ns.current_song_time
        fmt = Live.Song.TimeFormat.ms_time
        seconds = []
        tempos = []
        try:
            for b in beats:
                ns.current_song_time = max(0.0, float(b))
                t = ns.get_current_smpte_song_time(fmt)
                seconds.append(t.hours * 3600 + t.minutes * 60 + t.seconds + t.frames / 1000.0)
                tempos.append(ns.tempo)
        finally:
            ns.current_song_time = original
        return {"seconds": seconds, "tempos": tempos}

    def get_beat_position(self, ns):
        """Playhead in Live's OWN bar grid (honours time-signature changes),
        plus the raw beat time, in one round trip. The app derives where the
        current bar started from this, so downbeat jumps, count-ins and the
        bar display stay right after a 5/4 bar in a 4/4 song."""
        bt = ns.get_current_beats_song_time()
        return {
            "song_time": ns.current_song_time,
            "bars": bt.bars,
            "beats": bt.beats,
            "sub": bt.sub_division,
            "ticks": bt.ticks,
            "num": ns.signature_numerator,
            "den": ns.signature_denominator,
        }

    def set_appointed_device(self, ns, device_id):
        ns.appointed_device = Interface.get_obj(device_id)

    def set_clip_trigger_quantization(self, ns, name):
        ns.clip_trigger_quantization = getattr(Live.Song.Quantization, str(name))

    def set_midi_recording_quantization(self, ns, name):
        ns.midi_recording_quantization = getattr(
            Live.Song.RecordingQuantization, str(name)
        )

    def safe_start_playing(self, ns):
        if not self.song.is_playing:
            self.song.start_playing()
            return True

        return False

    def safe_stop_playing(self, ns):
        if self.song.is_playing:
            self.song.stop_playing()
            return True

        return False
