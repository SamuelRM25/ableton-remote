
import binascii
import hashlib
import hmac
import itertools
import json
import os
import queue
import socket
import threading
import time

from .Config import DEBUG, PASSWORD, PLUGIN_NAME, WEBSOCKET_HOST, WEBSOCKET_PORT
from .Logging import logger
from .StaticServer import serve_static
from .WebSocket import (
    OPCODE_CLOSE,
    OPCODE_CONTINUATION,
    OPCODE_PING,
    OPCODE_PONG,
    OPCODE_TEXT,
    complete_websocket_handshake,
    encode_close_frame,
    encode_pong_frame,
    encode_text_frame,
    is_websocket_upgrade,
    read_http_request,
    to_bytes,
    to_text,
    try_read_frame,
)

# Send small frames on the caller thread (usually Live's MIDI thread). A
# dedicated send thread adds ~10ms wake-up on macOS; keep it only for large
# payloads or when a previous send is still queued.
DIRECT_SEND_MAX_BYTES = 65536

# Bounds how long any blocking call on a client socket (send or recv) may
# block. Sends can happen synchronously on Live's own main thread (e.g. a
# listener callback pushing a property change), so without this a slow or
# stalled client could otherwise freeze the whole application indefinitely.
SOCKET_TIMEOUT_SECONDS = 10.0

# Push events (property-change listeners) are latency-sensitive UI state and
# should jump ahead of queued command results, which the client is already
# waiting on a promise for and can tolerate a bit more delay from. Pings and
# close frames also get the high lane so they aren't stuck behind a backlog
# of result frames.
PRIORITY_HIGH = 0
PRIORITY_LOW = 1
# Meters and playheads: dozens of values per second that are only ever
# "latest wins". They go last so a burst of them can never delay a button
# press, a command result or a state change (play, mute, clip launch…).
PRIORITY_BULK = 2

# Upper bound for how many bytes the send thread bundles into one sendall.
MAX_BATCH_BYTES = 1024 * 1024


def _auth_enabled():
    return bool(PASSWORD)


def _random_salt():
    raw = binascii.hexlify(os.urandom(16))
    if isinstance(raw, bytes):
        return raw.decode("ascii")
    return raw


def _auth_hash(salt):
    return hmac.new(to_bytes(PASSWORD), to_bytes(salt), hashlib.sha256).hexdigest()


class ClientConnection:
    """Socket with optional send thread for large or potentially blocking writes."""

    def __init__(self, sock):
        self.sock = sock
        self.sock.settimeout(SOCKET_TIMEOUT_SECONDS)

        try:
            host, port = sock.getpeername()[:2]
            self.peer = f"{host}:{port}"
        except:
            self.peer = "unknown"

        self.out_queue = queue.PriorityQueue()
        self._seq = itertools.count()
        self._send_lock = threading.Lock()
        self._closed = False
        self.authenticated = not _auth_enabled()
        self.auth_salt = None
        thread = threading.Thread(target=self._send_loop, daemon=True)
        thread.start()

    def send_or_enqueue(self, frame, priority=PRIORITY_LOW):
        if self._closed:
            return False

        if (
            self.out_queue.empty()
            and len(frame) <= DIRECT_SEND_MAX_BYTES
            and self._send_lock.acquire(False)
        ):
            try:
                if self._closed:
                    return False
                self.sock.sendall(frame)
                return True
            except OSError as e:
                # Includes socket.timeout. Part of the frame may already be
                # on the wire, so the stream can't be recovered.
                logger.warning(
                    f"[{self.peer}] Direct send of {len(frame)}B failed, "
                    f"dropping connection: {e!r}"
                )
                return False
            finally:
                self._send_lock.release()

        return self.enqueue(frame, priority)

    def enqueue(self, frame, priority=PRIORITY_LOW):
        if self._closed:
            return False
        # (priority, seq, queued_at, frame): seq breaks ties in insertion
        # order and, together with queued_at, keeps frames (bytes, or None
        # for the close sentinel) out of the comparison, since PriorityQueue
        # compares tuple elements left to right and would otherwise try to
        # compare frames against each other.
        self.out_queue.put_nowait((priority, next(self._seq), time.time(), frame))
        return True

    def close(self):
        if self._closed:
            return

        self._closed = True

        try:
            self.out_queue.put_nowait((PRIORITY_HIGH, next(self._seq), time.time(), None))
        except:
            pass

    def _send_loop(self):
        while True:
            priority, _seq, queued_at, frame = self.out_queue.get()
            if frame is None:
                break

            # Bundle everything that's already queued into this write.
            # The send thread only gets scheduled every ~20ms inside Live,
            # so sending one frame per pass can't keep up with bursts.
            batch = bytearray(frame)
            frame_count = 1
            oldest_queued_at = queued_at
            stop = False
            while len(batch) < MAX_BATCH_BYTES:
                try:
                    _priority, _seq, next_queued_at, next_frame = self.out_queue.get_nowait()
                except queue.Empty:
                    break
                if next_frame is None:
                    stop = True
                    break
                batch.extend(next_frame)
                frame_count += 1
                oldest_queued_at = min(oldest_queued_at, next_queued_at)

            wait = time.time() - oldest_queued_at

            if DEBUG:
                logger.info(
                    f"[{self.peer}] Sending batch after {round(wait * 1000)}ms in the "
                    f"send queue (priority={priority}, frames={frame_count}, "
                    f"size={len(batch)}B, remaining_depth={self.out_queue.qsize()})"
                )

            # Don't bail out on self._closed here: close() is called right
            # after a close frame was enqueued, and that frame must still go out.
            try:
                self._send_lock.acquire()
                try:
                    self.sock.sendall(batch)
                finally:
                    self._send_lock.release()
            except Exception as e:
                logger.warning(
                    f"[{self.peer}] Queued send of {len(batch)}B failed, "
                    f"dropping connection: {e!r}"
                )
                break

            if stop:
                break

        try:
            self.sock.close()
        except:
            pass


class Socket:
    @staticmethod
    def set_message(func):
        Socket.show_message = func

    def __init__(self, handler, disconnect_handler=None):
        self.input_handler = handler
        self.disconnect_handler = disconnect_handler
        self._queue = queue.Queue()
        self._connections = []
        self._lock = threading.Lock()
        self._socket = None
        self._running = True
        self._last_error = ""
        self._host = WEBSOCKET_HOST
        self._port = int(WEBSOCKET_PORT)

        self._thread = threading.Thread(target=self._serve, daemon=True)
        self._thread.start()

    def log_error_once(self, msg):
        if self._last_error != msg:
            self._last_error = msg
            logger.error(msg)

    def send_to(self, connection, name, obj=None, uuid=None, priority=None):
        self._send_json(name, obj, uuid, connection, priority)

    def broadcast(self, name, obj=None, uuid=None, priority=None):
        self._send_json(name, obj, uuid, None, priority)

    def _send_json(self, name, obj, uuid, connection, priority=None):
        def jsonReplace(o):
            try:
                return list(o)
            except:
                pass
            return str(o)

        # Command responses are matched by uuid on the client and it's
        # already waiting on that promise, so they can queue behind push
        # events, which drive live UI state and are latency-sensitive.
        # Results, errors and state pushes share the fast lane in arrival
        # order (the user is waiting on all of them); only bulk streams such
        # as meters are pushed to the back.
        if priority is None:
            priority = PRIORITY_HIGH

        try:
            data = json.dumps(
                {"event": name, "data": obj, "uuid": uuid, "ts": round(time.time() * 1000)},
                default=jsonReplace,
                ensure_ascii=False,
            )
            frame = encode_text_frame(to_bytes(data))
            if connection is None:
                self._broadcast_frame(frame, priority)
            else:
                self._send_frame(frame, connection, priority)
        except Exception as e:
            logger.error(f"Error {name}({uuid}):")
            logger.exception(e)

    def _send_frame(self, frame, connection, priority=PRIORITY_LOW):
        self._deliver_frame(frame, [connection], priority)

    def _broadcast_frame(self, frame, priority=PRIORITY_LOW):
        with self._lock:
            targets = list(self._connections)
        self._deliver_frame(frame, targets, priority)

    def _deliver_frame(self, frame, targets, priority=PRIORITY_LOW):
        stale = []
        for conn in targets:
            if not conn.send_or_enqueue(frame, priority):
                stale.append(conn)

        if stale:
            with self._lock:
                for conn in stale:
                    self._drop_connection(conn)

    def _drop_connection(self, conn):
        try:
            self._connections.remove(conn)
        except:
            pass
        conn.close()
        # Live listener teardown must run on the main thread via process().
        try:
            self._queue.put((conn, None))
        except:
            pass

    def shutdown(self):
        logger.info("Shutting down...")
        self._running = False
        with self._lock:
            clients = list(self._connections)
            self._connections = []
        for conn in clients:
            conn.enqueue(encode_close_frame(), PRIORITY_HIGH)
            conn.close()
        if self._socket:
            try:
                self._socket.close()
            except:
                pass
            self._socket = None

    # Called after every process() pass (set by DAWRemote) to flush
    # throttled listener values such as meters.
    after_process = None

    def process(self):
        try:
            self._process_queue()
        finally:
            if self.after_process is not None:
                try:
                    self.after_process()
                except Exception as e:
                    logger.error("Error flushing throttled listeners:")
                    logger.exception(e)

    def _process_queue(self):
        while True:
            try:
                connection, payload = self._queue.get_nowait()
            except queue.Empty:
                return
            try:
                if payload is None:
                    if self.disconnect_handler:
                        self.disconnect_handler(connection)
                elif self.input_handler:
                    self.input_handler(payload, connection)
            except Exception as e:
                logger.error("Error processing request:")
                logger.exception(e)

    def _serve(self):
        while self._running:
            try:
                self._bind_and_listen()
                self._accept_loop()
            except Exception as e:
                if not self._running:
                    return
                msg = (
                    f"ERROR: Cannot bind to {self._host}:{self._port}: {e.args}, trying again. If this keeps happening, try restarting your computer."
                )
                self.log_error_once(msg)
                self.show_message(msg)
                if self._socket:
                    try:
                        self._socket.close()
                    except:
                        pass
                    self._socket = None
                time.sleep(5)

    def _bind_and_listen(self):
        # Try IPv6 dual-stack first (also accepts IPv4), fall back to IPv4 only.
        # Apple devices on the same LAN prefer IPv6 (AAAA) first; if the server
        # only binds to IPv4, the device may time out before falling back to A.
        sock = None
        last_err = None
        for family, v6_only, bind_host in (
            (socket.AF_INET6, 0, "" if self._host in ("0.0.0.0", "") else self._host),
            (socket.AF_INET, None, self._host),
        ):
            try:
                s = socket.socket(family, socket.SOCK_STREAM)
                s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                if v6_only is not None:
                    s.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, v6_only)
                try:
                    s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                except Exception:
                    pass
                s.bind((bind_host, self._port))
                s.listen(16)
                sock = s
                self._family = family
                break
            except OSError as e:
                last_err = e
                try:
                    s.close()
                except Exception:
                    pass
        if sock is None:
            raise last_err or OSError("Could not bind socket")
        self._socket = sock
        self._last_error = ""
        bind_label = "::" if sock.family == socket.AF_INET6 else self._host
        logger.info(f"WebSocket server listening on {bind_label}:{self._port}")
        self.show_message(f"Started {PLUGIN_NAME} on {bind_label}:{self._port}")

    def _accept_loop(self):
        while self._running and self._socket:
            try:
                conn, addr = self._socket.accept()
            except OSError:
                if not self._running:
                    return
                continue
            try:
                conn.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            except:
                pass
            try:
                conn.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 4 * MAX_BATCH_BYTES)
            except:
                pass
            try:
                sndbuf = conn.getsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF)
            except:
                sndbuf = "unknown"

            # The OS may silently cap SO_SNDBUF, so log what we actually got.
            logger.info(f"Client connected: {addr} (send buffer: {sndbuf}B)")
            thread = threading.Thread(
                target=self._handle_connection, args=(conn,), daemon=True
            )
            thread.start()

    def _handle_connection(self, conn):
        parsed = read_http_request(conn)
        if parsed is None:
            try:
                conn.close()
            except:
                pass
            return

        method, path, headers, leftover = parsed

        if is_websocket_upgrade(headers):
            if not complete_websocket_handshake(conn, headers):
                try:
                    conn.close()
                except:
                    pass
                return
            self._handle_websocket(conn, leftover)
            return

        try:
            serve_static(conn, method, path)
        except Exception as e:
            logger.error("Static file error:")
            logger.exception(e)
        finally:
            try:
                conn.close()
            except:
                pass

    def _handle_websocket(self, conn, leftover):
        client = ClientConnection(conn)
        with self._lock:
            self._connections.append(client)

        connect_data = {"port": self._port}
        if _auth_enabled():
            client.auth_salt = _random_salt()
            connect_data["requiresAuth"] = True
            connect_data["salt"] = client.auth_salt
        self.send_to(client, "connect", connect_data)

        buffer = bytearray(to_bytes(leftover))
        fragments = bytearray()
        fragment_opcode = None

        try:
            while self._running:
                try:
                    data = conn.recv(65536)
                except socket.timeout:
                    continue
                except OSError:
                    break
                if not data:
                    break
                buffer.extend(bytearray(to_bytes(data)))

                while True:
                    frame = try_read_frame(buffer)
                    if frame is None:
                        break
                    opcode, fin, payload = frame

                    if opcode == OPCODE_CLOSE:
                        client.enqueue(encode_close_frame(), PRIORITY_HIGH)
                        return
                    if opcode == OPCODE_PING:
                        self._send_frame(encode_pong_frame(payload), client, PRIORITY_HIGH)
                        continue
                    if opcode == OPCODE_PONG:
                        continue

                    if opcode == OPCODE_CONTINUATION:
                        if fragment_opcode is None:
                            continue
                        fragments.extend(payload)
                        if fin:
                            self._handle_payload(fragment_opcode, fragments, client)
                            fragments = bytearray()
                            fragment_opcode = None
                        continue

                    if not fin:
                        fragment_opcode = opcode
                        fragments = bytearray(payload)
                        continue

                    self._handle_payload(opcode, payload, client)
        except Exception as e:
            logger.error("Connection error:")
            logger.exception(e)
        finally:
            with self._lock:
                self._drop_connection(client)
            logger.info(f"Client disconnected: {client.peer}")

    def _handle_payload(self, opcode, payload, client):
        if opcode != OPCODE_TEXT:
            return
        try:
            text = to_text(bytes(payload))
            parsed = json.loads(text)
        except Exception as e:
            logger.error("Error decoding request:")
            logger.exception(e)
            return

        if self._gate_auth(client, parsed):
            return

        self._queue.put((client, parsed))

    def _gate_auth(self, client, parsed):
        """Return True if the message was consumed and should not be queued."""
        if not _auth_enabled() or client.authenticated:
            return False

        uuid = parsed.get("uuid")
        commands = parsed.get("commands")
        if not isinstance(commands, list) or len(commands) == 0:
            self.send_to(client, "error", "Unauthorized", uuid)
            return True

        first = commands[0] or {}
        if first.get("ns") != "internal" or first.get("name") != "authenticate":
            self.send_to(client, "error", "Unauthorized", uuid)
            return True

        args = first.get("args") or {}
        if client.auth_salt and args.get("hash") == _auth_hash(client.auth_salt):
            client.authenticated = True
            logger.info("Client authenticated")
            return False

        logger.info("Client authentication failed")
        self.send_to(client, "error", "Invalid password", uuid)
        with self._lock:
            self._drop_connection(client)
        return True
